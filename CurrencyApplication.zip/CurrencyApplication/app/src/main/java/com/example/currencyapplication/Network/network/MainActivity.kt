package com.example.currencyapplication.Network.network

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyapplication.R
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var editTextAmount: EditText
    private lateinit var editTextFromCurrency: EditText
    private lateinit var editTextToCurrency: EditText
    private lateinit var buttonConvert: Button
    private lateinit var textViewResult: TextView

    private val apiKey = "9468876b4a7ade84b5ea0d765dce6af6ede94185"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextAmount = findViewById(R.id.editTextAmount)
        editTextFromCurrency = findViewById(R.id.editTextFromCurrency)
        editTextToCurrency = findViewById(R.id.editTextToCurrency)
        buttonConvert = findViewById(R.id.buttonConvert)
        textViewResult = findViewById(R.id.textViewResult)

        buttonConvert.setOnClickListener {
            val amount = editTextAmount.text.toString()
            val fromCurrency = editTextFromCurrency.text.toString()
            val toCurrency = editTextToCurrency.text.toString()

            if (amount.isNotEmpty() && fromCurrency.isNotEmpty() && toCurrency.isNotEmpty()) {
                convertCurrency(amount, fromCurrency, toCurrency)
            } else {
                textViewResult.text = "Please fill all fields"
            }
        }
    }

    private fun convertCurrency(amount: String, fromCurrency: String, toCurrency: String) {
        val call = RetrofitClient.currencyApiService.getExchangeRate(apiKey, fromCurrency, toCurrency, amount)
        call.enqueue(object : Callback<CurrencyResponse> {
            override fun onResponse(call: Call<CurrencyResponse>, response: Response<CurrencyResponse>) {
                if (response.isSuccessful) {
                    val conversionResult = response.body()
                    val rate = conversionResult?.rates?.get(toCurrency)?.rateForAmount ?: "0.0"
                    textViewResult.text = "Converted Amount: $rate $toCurrency"
                } else {
                    textViewResult.text = "Error: ${response.message()}"
                }
            }

            override fun onFailure(call: Call<CurrencyResponse>, t: Throwable) {
                Log.e("MainActivity", "onFailure: ${t.message}")
                textViewResult.text = "Failed to fetch conversion rate"
            }
        })
    }

    annotation class CurrencyResponse
}