package com.example.currencyapplication.Network.network

import com.google.gson.annotations.SerializedName

data class CurrencyResponse(
    @SerializedName("base_currency_code") val baseCurrencyCode: String,
    @SerializedName("base_currency_name") val baseCurrencyName: String,
    @SerializedName("amount") val amount: String,
    @SerializedName("rates") val rates: Map<String, RateDetail>
)

data class RateDetail(
    @SerializedName("currency_name") val currencyName: String,
    @SerializedName("rate") val rate: String,
    @SerializedName("rate_for_amount") val rateForAmount: String
)
